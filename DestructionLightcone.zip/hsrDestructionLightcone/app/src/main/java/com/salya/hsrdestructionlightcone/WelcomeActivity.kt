package com.salya.hsrdestructionlightcone

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class WelcomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.welcome)

        val btnMainActivity = findViewById<Button>(R.id.btn_main_activity)
        val btnAboutMe = findViewById<Button>(R.id.btn_about_me)

        btnMainActivity.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }

        btnAboutMe.setOnClickListener {
            startActivity(Intent(this, AboutMeActivity::class.java))
        }
    }
}
