package com.salya.hsrdestructionlightcone

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView

class ActivityDetail : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        // Retrieve data passed from ListLightconeAdapter
        val lightcone = intent.getParcelableExtra<Lightcone>("key_hero")

        // Display data in TextViews and ImageView
        lightcone?.let {
            findViewById<ImageView>(R.id.data_photo).setImageResource(it.photo)
            findViewById<TextView>(R.id.tv_lc_name).text = it.name
            findViewById<TextView>(R.id.tv_lc_description).text = it.description
        }
    }
}
